package com.example.elbagory.orthodroid.Models;

public class Model_Investigation {

    private String etChemistry, etCS, etCytology, etXray, etScanogram, etCT, etMRI, etDEXA, etBoneScan;
    private int Private_id;

    public Model_Investigation(String etChemistry, String etCS, String etCytology, String etXray, String etScanogram, String etCT, String etMRI, String etDEXA, String etBoneScan, int private_id) {
        this.etChemistry = etChemistry;
        this.etCS = etCS;
        this.etCytology = etCytology;
        this.etXray = etXray;
        this.etScanogram = etScanogram;
        this.etCT = etCT;
        this.etMRI = etMRI;
        this.etDEXA = etDEXA;
        this.etBoneScan = etBoneScan;
        Private_id = private_id;
    }

    public String getEtChemistry() {
        return etChemistry;
    }

    public String getEtCS() {
        return etCS;
    }

    public String getEtCytology() {
        return etCytology;
    }

    public String getEtXray() {
        return etXray;
    }

    public String getEtScanogram() {
        return etScanogram;
    }

    public String getEtCT() {
        return etCT;
    }

    public String getEtMRI() {
        return etMRI;
    }

    public String getEtDEXA() {
        return etDEXA;
    }

    public String getEtBoneScan() {
        return etBoneScan;
    }

    public int getPrivate_id() {
        return Private_id;
    }
}
