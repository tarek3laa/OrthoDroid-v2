package com.example.elbagory.orthodroid.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.elbagory.orthodroid.AddPatientActivity;
import com.example.elbagory.orthodroid.GetTimeFromInternet;
import com.example.elbagory.orthodroid.Models.AllInfo;
import com.example.elbagory.orthodroid.Models.Model_Patient;
import com.example.elbagory.orthodroid.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sdsmdg.tastytoast.TastyToast;

import java.util.HashMap;
import java.util.Map;


/**
 * this fragment contains patient info
 */
public class PatientFragment extends Fragment {
    static EditText etName, etId, etAge, etOccupation, etWeight, etInfo;
    public static final String ALL_PATIENT = "all_patient";
    public static final String PRIMARY_KEY = "Primary_key";
    // this Primary_key help us to get data for this user
    Integer Primary_key = 0;
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private final DatabaseReference databaseReference = firebaseDatabase.getReference();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_patient_info, container, false);

        //fire base


        // get the value of Primary_key from data base fire base

        databaseReference.child("Primary_key").child("Primary_key").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                Primary_key = dataSnapshot.getValue(Integer.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        //init view
        etName = view.findViewById(R.id.editTextName);
        etId = view.findViewById(R.id.editTextID);
        etAge = view.findViewById(R.id.editTextAge);
        etOccupation = view.findViewById(R.id.editTextOccupation);
        etWeight = view.findViewById(R.id.editTextWeight);
        etInfo = view.findViewById(R.id.editTextInfo);


        //save to DB

        Button button = view.findViewById(R.id.button);


        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {


                if (etName.getText().length() == 0 || etId.getText().length() == 0 ||
                        etAge.getText().length() == 0 || etOccupation.getText().length() == 0 ||
                        etWeight.getText().length() == 0 || etInfo.getText().length() == 0) {
                    TastyToast.makeText(getActivity(), "Something Missed....", TastyToast.LENGTH_SHORT,TastyToast.ERROR).show();


                } else {

                    Model_Patient model_patient = new Model_Patient(etName.getText().toString(),
                            etId.getText().toString(),
                            etAge.getText().toString(),
                            etOccupation.getText().toString(),
                            etWeight.getText().toString(),
                            etInfo.getText().toString(),
                            Primary_key,
                            new GetTimeFromInternet().getTime()
                    );
                    AddPatientActivity.allInfo.setPatient(model_patient);
                    // create new patient
                    databaseReference.child(ALL_PATIENT).child(String.valueOf(++Primary_key)).setValue(AddPatientActivity.allInfo);
                    updateID();
                    TastyToast.makeText(getActivity(), "Saved", TastyToast.LENGTH_SHORT, TastyToast.SUCCESS).show();
                    etName.setText("");
                    etId.setText("");
                    etAge.setText("");
                    etOccupation.setText("");
                    etWeight.setText("");
                    etInfo.setText("");
                }

            }
        });


        return view;
    }

    private void updateID() {

        Map<String, Object> map = new HashMap<>();
        map.put(PRIMARY_KEY, Primary_key);
        databaseReference.child(PRIMARY_KEY).updateChildren(map);
    }

}
