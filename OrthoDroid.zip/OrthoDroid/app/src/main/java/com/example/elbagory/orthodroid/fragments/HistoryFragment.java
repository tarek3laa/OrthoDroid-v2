package com.example.elbagory.orthodroid.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.elbagory.orthodroid.AddPatientActivity;
import com.example.elbagory.orthodroid.Models.Model_History;
import com.example.elbagory.orthodroid.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


/**
 * fragment contains History Info
 */
public class HistoryFragment extends Fragment {
    EditText etChronic, etGastritis, etSmoking, etPregnancy, etLactation;

    // this Primary_key help us to get data for this user

    Integer Primary_key = 0;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_history, container, false);

        //fire base
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        final DatabaseReference databaseReference = firebaseDatabase.getReference();


        etChronic = view.findViewById(R.id.ch);
        etGastritis = view.findViewById(R.id.ga);
        etSmoking = view.findViewById(R.id.smoking);
        etPregnancy = view.findViewById(R.id.pr);
        etLactation = view.findViewById(R.id.la);

        // get the value of Primary_key from data base fire base

        databaseReference.child("Primary_key").child("Primary_key").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Primary_key = dataSnapshot.getValue(Integer.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Button button = view.findViewById(R.id.button2);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Model_History model_history = new Model_History(etChronic.getText().toString(),

                        etGastritis.getText().toString(),
                        etSmoking.getText().toString(),
                        etPregnancy.getText().toString(),
                        etLactation.getText().toString(),
                        Primary_key);
                AddPatientActivity.allInfo.setHistory(model_history);

                databaseReference.child(PatientFragment.ALL_PATIENT).child(String.valueOf(Primary_key)).setValue(AddPatientActivity.allInfo);

                Toast.makeText(getActivity(), "Saved", Toast.LENGTH_SHORT).show();

                etChronic.setText("");
                etGastritis.setText("");
                etSmoking.setText("");
                etPregnancy.setText("");
                etLactation.setText("");
            }
        });


        return view;
    }


}