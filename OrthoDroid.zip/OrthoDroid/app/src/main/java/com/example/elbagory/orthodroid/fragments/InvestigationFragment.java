package com.example.elbagory.orthodroid.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.elbagory.orthodroid.AddPatientActivity;
import com.example.elbagory.orthodroid.Models.Model_Investigation;
import com.example.elbagory.orthodroid.Models.Model_Patient;
import com.example.elbagory.orthodroid.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * fragment contains Investigation Info
 */
public class InvestigationFragment extends Fragment {
    EditText etChemistry, etCS, etCytology, etXray, etScanogram, etCT, etMRI, etDEXA, etBoneScan;

    int Primary_key=0;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_investigation, container, false);


        //fire base
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        final DatabaseReference databaseReference = firebaseDatabase.getReference();






        // get the value of Primary_key from data base fire base

        databaseReference.child("Primary_key").child("Primary_key").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Primary_key = dataSnapshot.getValue(Integer.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        // init view
        etChemistry = view.findViewById(R.id.editTextChemistry);
        etCS = view.findViewById(R.id.editTextCS);
        etCytology = view.findViewById(R.id.editTextCytology);
        etXray = view.findViewById(R.id.editTextX_ray);
        etScanogram = view.findViewById(R.id.editTextScanogram);
        etCT = view.findViewById(R.id.editTextC_T);
        etMRI = view.findViewById(R.id.editTextMRI);
        etDEXA = view.findViewById(R.id.editTextDEXA);
        etBoneScan = view.findViewById(R.id.editTextBone);


        Button button = view.findViewById(R.id.button3);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Model_Investigation model_investigation = new Model_Investigation(etChemistry.getText().toString(),
                        etCS.getText().toString(),
                        etCytology.getText().toString(),
                        etXray.getText().toString(),
                        etScanogram.getText().toString(),
                        etCT.getText().toString(),
                        etMRI.getText().toString(),
                        etDEXA.getText().toString(),
                        etBoneScan.getText().toString(),
                        Primary_key
                );

                AddPatientActivity.allInfo.setInvestigation(model_investigation);

                databaseReference.child(PatientFragment.ALL_PATIENT).child(String.valueOf(Primary_key)).setValue(AddPatientActivity.allInfo);


                Toast.makeText(getActivity(), "Saved", Toast.LENGTH_SHORT).show();

                etChemistry.setText("");
                etCS.setText("");
                etCytology.setText("");
                etXray.setText("");
                etScanogram.setText("");
                etCT.setText("");
                etMRI.setText("");
                etDEXA.setText("");
                etBoneScan.setText("");
            }
        });



        return view;
    }
}