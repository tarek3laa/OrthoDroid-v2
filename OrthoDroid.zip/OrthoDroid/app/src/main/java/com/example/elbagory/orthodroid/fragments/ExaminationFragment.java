package com.example.elbagory.orthodroid.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.elbagory.orthodroid.AddPatientActivity;
import com.example.elbagory.orthodroid.Models.Model_Examination;
import com.example.elbagory.orthodroid.Models.Model_Investigation;
import com.example.elbagory.orthodroid.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * fragment contains Examination Info
 */
public class ExaminationFragment extends Fragment {
    private EditText etTrauma, etKnee, etShoulder, etSpine, etPelvis, etFoot, etElbow;

    int Primary_key=0;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_examination, container, false);


        //fire base
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        final DatabaseReference databaseReference = firebaseDatabase.getReference();





        // get the value of Primary_key from data base fire base

        databaseReference.child("Primary_key").child("Primary_key").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Primary_key = dataSnapshot.getValue(Integer.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        // init view
        etTrauma = view.findViewById(R.id.editTextTrauma);
        etKnee = view.findViewById(R.id.editTextKnee);
        etShoulder = view.findViewById(R.id.editTextShoulder);
        etSpine = view.findViewById(R.id.editTextSpine);
        etPelvis = view.findViewById(R.id.editTextPelvis);
        etFoot = view.findViewById(R.id.editTextFoot);
        etElbow = view.findViewById(R.id.editTextElbow);



        Button button = view.findViewById(R.id.button4);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                 Model_Examination model_examination = new Model_Examination(etTrauma.getText().toString(),
                        etKnee.getText().toString(),
                        etShoulder.getText().toString(),
                        etSpine.getText().toString(),
                        etPelvis.getText().toString(),
                        etFoot.getText().toString(),
                        etElbow.getText().toString(),
                        Primary_key
                );
                AddPatientActivity.allInfo.setExamination(model_examination);
                databaseReference.child(PatientFragment.ALL_PATIENT).child(String.valueOf(Primary_key)).setValue(AddPatientActivity.allInfo);


                Toast.makeText(getActivity(), "Saved", Toast.LENGTH_SHORT).show();


                etTrauma.setText("");
                etKnee.setText("");
                etShoulder.setText("");
                etSpine.setText("");
                etPelvis.setText("");
                etFoot.setText("");
                etElbow.setText("");

            }
        });


        return view;
    }
}