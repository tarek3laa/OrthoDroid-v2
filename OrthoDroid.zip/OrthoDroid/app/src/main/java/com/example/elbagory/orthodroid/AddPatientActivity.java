package com.example.elbagory.orthodroid;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.example.elbagory.orthodroid.Models.AllInfo;
import com.example.elbagory.orthodroid.fragments.ExaminationFragment;
import com.example.elbagory.orthodroid.fragments.FragmentSurgery;
import com.example.elbagory.orthodroid.fragments.HistoryFragment;
import com.example.elbagory.orthodroid.fragments.InvestigationFragment;
import com.example.elbagory.orthodroid.fragments.OperationFragment;
import com.example.elbagory.orthodroid.fragments.PatientFragment;


public class AddPatientActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    ViewPager viewPager;
    public static AllInfo allInfo = new AllInfo();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_patient);

        try {


            viewPager = findViewById(R.id.container);
            setSectionPageAdapter(viewPager);
            TabLayout tabLayout = findViewById(R.id.tabs);
            tabLayout.setupWithViewPager(viewPager);

        } catch (Exception e) {
            Log.e(TAG, "onCreate: ", e);
        }
    }

    /**
     * add all fragment and fragment title to the  adapter,and set this adapter to view pager
     *
     * @param viewPager container that contains fragments
     */
    private void setSectionPageAdapter(ViewPager viewPager) {
        try {


            SectionPageAdapter pageAdapter = new SectionPageAdapter(getSupportFragmentManager());
            pageAdapter.addFragment(new PatientFragment(), "Patient Info");
            pageAdapter.addFragment(new HistoryFragment(), "History");
            pageAdapter.addFragment(new InvestigationFragment(), "Investigation");
            pageAdapter.addFragment(new ExaminationFragment(), "Examination");
            pageAdapter.addFragment(new OperationFragment(), "Operation");
            pageAdapter.addFragment(new FragmentSurgery(), "Surgery");

            viewPager.setAdapter(pageAdapter);

        } catch (Exception e) {
            Log.e(TAG, "setSectionPageAdapter: ", e);
        }
    }


}
