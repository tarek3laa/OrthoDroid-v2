package com.example.elbagory.orthodroid.Models;


public class Model_Examination {

    private String etTrauma, etKnee, etShoulder, etSpine, etPelvis, etFoot, etElbow;
    private int Private_id;

    public Model_Examination(String etTrauma, String etKnee, String etShoulder, String etSpine, String etPelvis, String etFoot, String etElbow, int private_id) {
        this.etTrauma = etTrauma;
        this.etKnee = etKnee;
        this.etShoulder = etShoulder;
        this.etSpine = etSpine;
        this.etPelvis = etPelvis;
        this.etFoot = etFoot;
        this.etElbow = etElbow;
        this.Private_id = private_id;
    }

    public String getEtTrauma() {
        return etTrauma;
    }

    public String getEtKnee() {
        return etKnee;
    }

    public String getEtShoulder() {
        return etShoulder;
    }

    public String getEtSpine() {
        return etSpine;
    }

    public String getEtPelvis() {
        return etPelvis;
    }

    public String getEtFoot() {
        return etFoot;
    }

    public String getEtElbow() {
        return etElbow;
    }

    public int getPrivate_id() {
        return Private_id;
    }
}
