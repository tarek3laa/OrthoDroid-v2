package com.example.elbagory.orthodroid.Models;

public class Model_History {

   private String PChronic, PGastritis, PSmoking, PPregnancy, PLactation;
   private int Private_id;


    public Model_History(String PChronic, String etGastritis, String etSmoking, String etPregnancy, String etLactation,int Privateid) {
        this.PChronic = PChronic;
        this.PGastritis = etGastritis;
        this.PSmoking = etSmoking;
        this.PPregnancy = etPregnancy;
        this.PLactation = etLactation;
        this.Private_id =Privateid;

    }


    public String getPChronic() {
        return PChronic;
    }

    public String getPGastritis() {
        return PGastritis;
    }

    public String getPSmoking() {
        return PSmoking;
    }

    public String getPPregnancy() {
        return PPregnancy;
    }

    public String getPLactation() {
        return PLactation;
    }

    public int getPrivate_id() {
        return Private_id;
    }
}
