package com.example.elbagory.orthodroid;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.util.Pair;

import java.util.ArrayList;
import java.util.List;

public class SectionPageAdapter extends FragmentStatePagerAdapter {
    private List<Pair<Fragment, String>> fragments = new ArrayList<>();

    public SectionPageAdapter(FragmentManager fm) {
        super(fm);
    }

    public void addFragment(Fragment fragment, String title) {

        fragments.add(new Pair<Fragment, String>(fragment, title));


    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return fragments.get(position).second;
    }

    @Override
    public Fragment getItem(int i) {
        return fragments.get(i).first;
    }

    @Override
    public int getCount() {
        return fragments.size();
    }
}
