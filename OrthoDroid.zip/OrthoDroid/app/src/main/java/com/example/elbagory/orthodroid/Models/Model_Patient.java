package com.example.elbagory.orthodroid.Models;

import android.widget.EditText;

public class Model_Patient {

   private String Name, Id, Age, Occupation, Weight, Info,lastUpdate;
   private int Private_id;

    // for fire base
    public Model_Patient() {
    }

    public Model_Patient(String name, String id, String age, String occupation, String weight, String info, int Privateid, String last_Update) {
        this.Name = name;
        this.Id = id;
        this.Age = age;
        this.Occupation = occupation;
        this.Weight = weight;
        this.Info = info;
        this.Private_id =Privateid;
        this.lastUpdate = last_Update;

    }

    public String getName() {
        return Name;
    }

    public String getId() {
        return Id;
    }

    public String getAge() {
        return Age;
    }

    public String getLastUpdate() {
        return lastUpdate;
    }

    public String getOccupation() {
        return Occupation;
    }

    public String getWeight() {
        return Weight;
    }

    public String getInfo() {
        return Info;
    }

    public int getPrivate_id() {
        return Private_id;
    }
}
