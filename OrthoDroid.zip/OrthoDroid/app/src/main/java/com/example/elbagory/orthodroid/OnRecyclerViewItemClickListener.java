package com.example.elbagory.orthodroid;

import android.view.View;

public interface OnRecyclerViewItemClickListener {
    void onItemClick(int position, View view);
}
