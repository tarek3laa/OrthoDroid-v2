package com.example.elbagory.orthodroid.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.elbagory.orthodroid.AddPatientActivity;
import com.example.elbagory.orthodroid.HomeActivity;
import com.example.elbagory.orthodroid.Models.Model_Operation;
import com.example.elbagory.orthodroid.Models.RecyclerViewRow_Model;
import com.example.elbagory.orthodroid.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.sdsmdg.tastytoast.TastyToast;

import java.util.HashMap;
import java.util.Map;

/**
 * fragment contains Operation info
 */
public class OperationFragment extends Fragment {
    EditText etOperationName, etDate, etSteps, etPersonName, etFollow;

    private int Primary_key = 0, private_id;
    String name, id, time;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_operation, container, false);


        //fire base
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        final DatabaseReference databaseReference = firebaseDatabase.getReference();


        // get the value of Primary_key from data base fire base

        databaseReference.child("Primary_key").child("Primary_key").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Primary_key = dataSnapshot.getValue(Integer.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        // init view
        etOperationName = view.findViewById(R.id.editTextOPname);
        etDate = view.findViewById(R.id.editTextOPDate);
        etSteps = view.findViewById(R.id.editTextSteps);
        etPersonName = view.findViewById(R.id.editTextPersons);
        etFollow = view.findViewById(R.id.editTextFollowUp);


        Button button = view.findViewById(R.id.button5);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Model_Operation model_operation = new Model_Operation(etOperationName.getText().toString(),
                        etDate.getText().toString(),
                        etSteps.getText().toString(),
                        etPersonName.getText().toString(),
                        etFollow.getText().toString(),
                        Primary_key
                );
                AddPatientActivity.allInfo.setOperation(model_operation);
                databaseReference.child(PatientFragment.ALL_PATIENT).child(String.valueOf(Primary_key)).setValue(AddPatientActivity.allInfo);


                TastyToast.makeText(getActivity(), "Saved", Toast.LENGTH_SHORT,TastyToast.SUCCESS).show();


                etOperationName.setText("");
                etDate.setText("");
                etSteps.setText("");
                etPersonName.setText("");
                etFollow.setText("");







            }
        });


        return view;
    }
}
